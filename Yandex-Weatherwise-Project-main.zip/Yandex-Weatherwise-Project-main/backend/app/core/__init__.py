"""Core backend configuration utilities."""

