"""Data loading utilities."""

